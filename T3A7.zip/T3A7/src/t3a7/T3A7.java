package t3a7;

import java.util.Scanner;

public class T3A7 {

    public static void main(String[] args) {
    //ejercio1();
    //ejercio2();
    //ejercicio3();
    ejercicio4();    
    }
    
     public static void ejercio1() {
       Scanner scanner = new Scanner(System.in);
       
       System.out.println("Cu�ntos n�meros quieres sumar: " );
       int limite = scanner.nextInt();
        
       System.out.println ("Desde que n�mero desea iniciar: " );
       int inicio = scanner.nextInt();
        
       System.out.println("Incremento: " );
       int incremento = scanner.nextInt();
       
       int numsuma = inicio + limite;
         System.out.println("Inicio:" + inicio
                 + "\nL�mite:" + numsuma
                 + "\nCantidad de n�meros a sumar:" + limite);
         
         int suma = 0;
         for (int numero = inicio; numero <= numsuma; numero += incremento){
             suma = suma + numero; 
        System.out.println("Suma de los n�meros " + numero);
        }  
         }
    public static void ejercicio2(){
	    	Scanner scanner = new Scanner(System.in);
	    	
	    	System.out.println("Ingresa el primer n�mero impar");
	    	int N1 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el segundo n�mero impar");
	    	int N2 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el tercer n�mero impar");
	    	int N3 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el cuarto n�mero impar");
	    	int N4 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el quinto n�mero impar");
	    	int N5 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el sexto n�mero impar");
	    	int N6 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el septimo n�mero impar");
	    	int N7 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el octavo n�mero impar");
	    	int N8 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el noveno n�mero impar");
	    	int N9 = scanner.nextInt();
	    	
	    	System.out.println("Ingresa el decimo n�mero impar");
	    	int N10 = scanner.nextInt();
	    	
	    	int producto = (((((((((N1 * N2) * N3) * N4) * N5) * N6) * N7) * N8) * N9) * N10);
	    	System.out.println("El producto es: " + producto);
	    	
	    }
    
      public static void ejercicio3(){
	    	Scanner scanner = new Scanner(System.in);
	    	
	    	System.out.println("Ingresa tu nombre");
	    	String Nom = scanner.next();
	    	
	    	System.out.println("Ingresa tu salario");
	    	double Sal = scanner.nextDouble();
	    	
	    	System.out.println("Ingresa tu nombre");
	    	String Nom1 = scanner.next();
	    	
	    	System.out.println("Ingresa tu salario");
	    	double Sal1 = scanner.nextDouble();
	    	
	    	System.out.println("Ingresa tu nombre");
	    	String Nom2 = scanner.next();
	    	
	    	System.out.println("Ingresa tu salario");
	    	double Sal2 = scanner.nextDouble();
	    	
	    	System.out.println("Ingresa tu nombre");
	    	String Nom3 = scanner.next();
	    	
	    	System.out.println("Ingresa tu salario");
	    	double Sal3 = scanner.nextDouble();
	    	
	    	System.out.println("Ingresa tu nombre");
	    	String Nom4 = scanner.next();
	    	
	    	System.out.println("Ingresa tu salario");
	    	double Sal4 = scanner.nextDouble();
	    	
	    	double prosalario = (Sal + Sal1 + Sal2 + Sal3 + Sal4) / 5;
	    	System.out.println("El promedio de los salarios es: " + prosalario);
	    	
	    }
    
     //Dadas las edades y alturas de 5 alumnos, mostrar la edad y la estatura media, la cantidad de 
     //alumnos mayores de 18 a�os, y la cantidad de alumnos que miden m�s de 1.75.
        public static void ejercicio4(){
        Scanner scanner = new Scanner(System.in);
        int edad;
        int mayorDe18 = 0;
        int mayorDe175 = 0;
        float estatura,sumaEstatura;
        double promedioEstatura;
    
      for (int i=0; i < 5; i++) {
          System.out.print("Edad: ");
          edad = scanner.nextInt();
          
          if (edad >=18){
              mayorDe18++;
          }
          
          System.out.println("Estatura: ");
          estatura = scanner.nextFloat();
          
          if (estatura >= 1.75){
              mayorDe175++;
          }
  
          estatura += estatura;
          promedioEstatura = estatura/5;
      
      }
            System.out.print("\n Mayor de 18 a�os: " + mayorDe18);
            System.out.println("\n Mayor de 1.75: " + mayorDe175);
     }
     
}

